<?php
//쿠키정보로 로그인 
$loginAble = false;
$name = "UNKNOWN";
if (isset($_COOKIE['memberDataEmail']) && isset($_COOKIE['memberDataPw'])) {
  $email = $_COOKIE['memberDataEmail'];
  $password = $_COOKIE['memberDataPw'];
  //mysql 접속
  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  //email이 $email인 사람 정보 가져오기
  $check = "SELECT * FROM members WHERE email='$email' ";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  if (mysqli_num_rows($result) > 0) {
      //비밀번호 검증로직
      $hashedPassword = $row['pw']; 
      $passwordResult = password_verify($password, $hashedPassword);
      if ($passwordResult) {
        //로그인 허용
        $_SESSION['email'] = $row['email'];
        $name = $row['name'];
        $loginAble = true; //쿠키정보로 로그인
        mysqli_close($mysqli);
      }
  }else{
    mysqli_close($mysqli);
  }
}
//세션정보로 로그인
session_start();
if ($loginAble == false) {
  if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    //mysql 접속
    $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
    //email이 $email인 사람 정보 가져오기
    $check = "SELECT * FROM members WHERE email='$email' ";
    $result = $mysqli->query($check);
    $row = mysqli_fetch_array($result);
      if (mysqli_num_rows($result) > 0) {
        //이메일 검증로직
        $mysqlEmail = $row['email']; 
          if ($mysqlEmail == $email) {
            //로그인 허용
            $name = $row['name'];
            $loginAble = true; //세션정보로 로그인
          }
      }
        mysqli_close($mysqli);
  }

}
?>

<?php 
//벤 여부 판단
if ($loginAble == true) {
  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  $check = "SELECT * FROM members WHERE email='$email'";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  if (mysqli_num_rows($result) > 0) {
    //객체가 존재한다면(객체는 무조건 존재해야함. 만약 없다면 오류)
    $ban_bool = $row['ban_bool'];
    if ($ban_bool == 1) {
      //밴이라면


    }else{
      //밴이 아니라면


    }
  }
}

?>

<?php 
if ($loginAble == false) {
        echo "<script language=javascript> alert('로그인 후 이용 가능합니다.'); window.location = './book_register.php'; </script>";
      exit;
}
?>
<?php
//버튼 이벤트
function logout() {
  session_destroy();
  unset($_COOKIE['memberDataEmail']);
  unset($_COOKIE['memberDataPw']);
  setcookie('memberDataEmail', '', time() - 3600, '/');
  setcookie('memberDataPw', '', time() - 3600, '/');
  header("location: ./index.php");

} 
function login() {
  header("location: ./login.php");
} 
function bookDelete(){
  if (isset($_POST['bookDelete'])) {
    $bookId = $_POST['bookId'];
    $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
    $check = "DELETE FROM books WHERE _id = $bookId";
    $result = $mysqli->query($check);
    header("location: ./search.php");
    mysqli_close($mysqli);
  
  }

}
if(array_key_exists('logout',$_POST)){ 
  logout(); 
}
if(array_key_exists('login',$_POST)){ 
  login(); 
}
if(array_key_exists('bookDelete',$_POST)){ 
  bookDelete();
}
?>

<?php 
//mysql 접속
//인기도서, 추천도서 정보 불러오기
//$mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
//$check = "";
//$result = $mysqli->query($check);
//if (mysqli_fetch_array($result) > 0) {
  
//}


?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>도서관 통합 자료 검색</title>

    <style type="text/css">
      body {
        background: url("./images/main_theme1.png");
        position: center;
        background-size: cover;
        height: 100vh; //Change this as per design needs
        width: 100%; //Change this as per design needs
        opacity: 0.5;
      

      }


      h1 {
          text-align: center;
          font-size: 90px;
      }
      h1 span:nth-child(1) {
          color:#4285f4;
      }
      h1 span:nth-child(2) {
          color:#ea4335;
      }
      h1 span:nth-child(3) {
          color:#fbbc05;
      }
      h1 span:nth-child(4) {
          color:#4285f4;
      }
      h1 span:nth-child(5) {
          color:#34a853;
      }
      h1 span:nth-child(6) {
          color:#ea4335;
      }
      .search-bar {
        width: 100%;
      }
  </style>
  </head>
  <body>
    <!--JavaScript-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

<!--navigation-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Library</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php">도서관소개</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./search.php">도서검색</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./demandBook.php">책 요청 게시판</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./iBookedBook.php">예약한책</a>
        </li>
        <?php 
        if (isset($_SESSION['admin'])) {
          if ($_SESSION['admin'] == 1) {
            //어드민 인증완료 네비게이션에 어드민창으로 가는 li추가
            echo "
        <li class='nav-item'>
          <a class='nav-link' href='./book_register.php'>도서 등록(관리자전용)</a>
        </li>
            ";
          }
        }
        ?>
      </ul>
              <?php 
    if ($loginAble == true) {
      echo "      
      <form class='d-flex' method='post' action='./index.php'>
        <span class='navbar-text'>
          $name 님 환영합니다&nbsp;&nbsp;&nbsp;
        </span>
        <input class='btn btn-outline-dark' type='submit' name='logout' value='Logout'></input>
      </form>";
    }else{

        echo "
      <form class='d-flex' method='post' action='./index.php'>
        <input class='btn btn-outline-dark' type='submit' name='login' value='Login'></input>
      </form>";

     
    }
 ?>
    </div>
  </div>
</nav>    


<!--컨테이너-->
<br>
<main class="container bg-light">

<?php 
if (isset($_GET['q'])) {
  $q = $_GET['q'];

  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  $check = "SELECT  count(*) as cnt FROM books WHERE title LIKE '%$q%'";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  $cnt = $row['cnt'];
  $emptyPivot = 0;
  echo "
  <div class='row row-cols-1 row-cols-md-6 g-4'>
  ";
  for ($i=0; $i < $cnt; $i++) { 
    $check = "SELECT * FROM books WHERE title LIKE '%$q%'  limit $i,1";
    $result = $mysqli->query($check);
    $row = mysqli_fetch_array($result);

    if (mysqli_num_rows($result) > 0) {
      $title = $row['title'];
      $author = $row['author'];
      $img_location = $row['img_location'];
      $bookId = (int)$row['_id'];
      //레코드가 존재한다면
      echo "
    <div class='card h-100'> 
      <img src='$img_location' class='card-img-top' alt='...'>
      <div class='card-body'>
        <form class='col' method='get' action='./openbook.php'>     
        <p class='card-title'>$title</p>
        <p class='card-text'>$author</p>
        <input type='submit' class='btn btn-outline-dark' value='열람'></input>
        <input type='hidden'  name='postnumber' value='$bookId'>
        </form> ";

             if (isset($_SESSION['admin'])) {
        echo "<form method='post' action='./search.php'>";
        echo "<input type='submit' class='btn btn-outline-warning' value='삭제' name='bookDelete'></input>";
        echo "<input type='hidden' id='bookId' name='bookId' value='$bookId'>";
        echo "</form>";
      } 

      echo "</div>";
    
        
  
echo "</div>";
      $emptyPivot++;
    }  

  }
    mysqli_close($mysqli);
    echo "</div>";

  if($emptyPivot == 0){
    echo "
<br>
<div class='alert alert-secondary' role='alert'>
  검색된 자료가 없습니다
</div>
    ";
  }

}else{

  echo "
  <h3>내가 '예약'한 책</h3>
  <div class='row row-cols-1 row-cols-md-6 g-4'>
  ";

  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  $uusseerrEmail=$_SESSION['email'];
  $check = "SELECT * from members WHERE email='$uusseerrEmail'";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  $uusseerrId = $row['_id'];

  for ($i=0; $i < 6; $i++) { 
    $pivot = $i+1;
    
    $check = "SELECT * from books WHERE booked_member=$uusseerrId order by views desc limit $i, 1";
    $result = $mysqli->query($check);
    $row = mysqli_fetch_array($result);
    if (mysqli_num_rows($result) > 0) {
      $title = $row['title'];
      $author = $row['author'];
      $img_location = $row['img_location'];
      $bookId = (int)$row['_id'];

      echo "
    <div class='card h-100'> 
      <img src='$img_location' class='card-img-top' alt='...'>
      <div class='card-body'>
        <form class='col' method='get' action='./openbook.php'>     
        <p class='card-title'>$title</p>
        <p class='card-text'>$author</p>
        <input type='submit' class='btn btn-outline-dark' value='열람'></input>
        <input type='hidden'  name='postnumber' value='$bookId'>
        </form> ";

             if (isset($_SESSION['admin'])) {
        echo "<form method='post' action='./search.php'>";
        echo "<input type='submit' class='btn btn-outline-warning' value='삭제' name='bookDelete'></input>";
        echo "<input type='hidden' id='bookId' name='bookId' value='$bookId'>";
        echo "</form>";
      } 

      echo "</div>";
    
        
  
echo "</div>";
    }
  }
  mysqli_close($mysqli);
  echo "
  </div>
  ";


}
?>


</main>






  </body>
</html>