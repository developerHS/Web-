<?php
session_start();
//쿠키정보로 로그인 
$loginAble = false;
$name = "UNKNOWN";
if (isset($_COOKIE['memberDataEmail']) && isset($_COOKIE['memberDataPw'])) {
  $email = $_COOKIE['memberDataEmail'];
  $password = $_COOKIE['memberDataPw'];
  //mysql 접속
  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  //email이 $email인 사람 정보 가져오기
  $check = "SELECT * FROM members WHERE email='$email' ";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  if (mysqli_num_rows($result) > 0) {
      //비밀번호 검증로직
      $hashedPassword = $row['pw']; 
      $passwordResult = password_verify($password, $hashedPassword);
      if ($passwordResult) {
        //로그인 허용
        $_SESSION['email'] = $row['email'];
        $name = $row['name'];
        $_SESSION['name'] = $name;
        $loginAble = true; //쿠키정보로 로그인
        mysqli_close($mysqli);
      }
  }else{
    mysqli_close($mysqli);
  }
}
//세션정보로 로그인
if ($loginAble == false) {
  if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    //mysql 접속
    $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
    //email이 $email인 사람 정보 가져오기
    $check = "SELECT * FROM members WHERE email='$email' ";
    $result = $mysqli->query($check);
    $row = mysqli_fetch_array($result);
      if (mysqli_num_rows($result) > 0) {
        //이메일 검증로직
        $mysqlEmail = $row['email']; 
          if ($mysqlEmail == $email) {
            //로그인 허용
            $name = $row['name'];
            $_SESSION['name'] = $name;
            $loginAble = true; //세션정보로 로그인
          }
      }
        mysqli_close($mysqli);
  }

}
?>

<?php 
//벤 여부 판단
if ($loginAble == true) {
  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  $check = "SELECT * FROM members WHERE email='$email'";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  if (mysqli_num_rows($result) > 0) {
    //객체가 존재한다면(객체는 무조건 존재해야함. 만약 없다면 오류)
    $ban_bool = $row['ban_bool'];
    if ($ban_bool == 1) {
      //밴이라면


    }else{
      //밴이 아니라면


    }
  }
}

?>

<?php
//버튼 이벤트
function logout() {
  session_destroy();
  unset($_COOKIE['memberDataEmail']);
  unset($_COOKIE['memberDataPw']);
  setcookie('memberDataEmail', '', time() - 3600, '/');
  setcookie('memberDataPw', '', time() - 3600, '/');
  header("location: ./index.php");

} 
function login() {
  header("location: ./login.php");

} 
if(array_key_exists('logout',$_POST)){ 
  logout(); 
}
if(array_key_exists('login',$_POST)){ 
  login(); 
}
?>



<?php 

function cleanStr($str) { //포스트 쓸때 한글, 영어, 숫자 빼고 모두 제거
  $special_pattern = "/[`~@#$&*|\\\'\";:\/^=^+_<>]/"; //정규표현식
  if( preg_match($special_pattern, $str) ){  //특수문자 제거 
      echo "<script language=javascript> if (confirm('특수문자는 사용할수 없습니다.') == true){  location.href = '  ./post.php';}else{location.href = './post.php';}</script>";
    exit(); 
  } else {
    return $str;
    exit();
  }
  
}

function post($title, $contents){

  $id=$_SESSION['email'];
  if (!isset($_SESSION['email'])) { //최종 권한 검증
      echo "<script language=javascript> if (confirm('세션이 존제하지 않습니다. 다시 로그인 해주십시오.') == true){  location.href = ' ./login.php';}else{location.href = ' ./login.php';}</script>"; 
      exit();
  }

  if ($title=='' or $contents=='') { //제목, 콘텐츠 공백 확인 솔루션/
        echo "<script language=javascript> if (confirm('빈칸을 모두 채워 주세요.') == true){  location.href = ' ./post.php';}else{location.href = './post.php';}</script>"; 
      exit();
  }


  $mysqli=mysqli_connect("localhost","root","hs5764438!","library");
  $timestamp = strtotime("+7 hours");
  $time = date("Y-m-d H:i:s", $timestamp);
  $username = $_SESSION['name'];
  $check="INSERT INTO bookNoticeBoard (title, name, nowtime ,contents) VALUES ('$title', '$username', '$time', '$contents')";
  if($mysqli->query($check)){
      echo "<script language=javascript> if (confirm('포스트 저장 완료.') == true){  location.href = ' ./demandBook.php';}else{location.href = ' ./demandBook.php';}</script>"; 
      exit();
  }else{
    echo "<script language=javascript> if (confirm('예기치 못한 오류가 발생했습니다. 나중에 다시 시도해 주세요.') == true){  location.href = './demandBook.php';}else{location.href = ' ./demandBook.php';}</script>"; 
    exit();
  } 
}


  if(array_key_exists('post',$_POST)){
    post(cleanStr($_POST['title']), cleanStr($_POST['contents']));
    }
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>

    <style type="text/css">
      body {
        background: url("./images/main_theme1.png");
        position: center;
        background-size: cover;
        height: 100vh; //Change this as per design needs
        width: 100%; //Change this as per design needs
        opacity: 0.5;

      }

    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  </head>
  <body>
    <!--JavaScript-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

<!--navigation-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Library</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php">도서관소개</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./search.php">도서검색</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./demandBook.php">책 요청 게시판</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./iBookedBook.php">예약한책</a>
        </li>
        <?php 
        if (isset($_SESSION['admin'])) {
          if ($_SESSION['admin'] == 1) {
            //어드민 인증완료 네비게이션에 어드민창으로 가는 li추가
            echo "
        <li class='nav-item'>
          <a class='nav-link' href='./book_register.php'>도서 등록(관리자전용)</a>
        </li>
            ";
          }
        }
        ?>
      </ul>
              <?php 
    if ($loginAble == true) {
      echo "      
      <form class='d-flex' method='post' action='./index.php'>
        <span class='navbar-text'>
          $name 님 환영합니다&nbsp;&nbsp;&nbsp;
        </span>
        <input class='btn btn-outline-dark' type='submit' name='logout' value='Logout'></input>
      </form>";
    }else{

        echo "
      <form class='d-flex' method='post' action='./index.php'>
        <input class='btn btn-outline-dark' type='submit' name='login' value='Login'></input>
      </form>";

     
    }
 ?>
    </div>
  </div>
</nav>  


<!--컨테이너-->
<br>

<main role="main" class="container bg-light">
  <h2 class="text-center">글쓰기</h2>
<section class="section">
      <form method="post" action="./post.php" style="width: 100%;"> 
          <div style=" height: 7%;">
            <p style="width: calc(10% - 8px;); height: 100%; float: left; font-size: 13px; margin: 0;">Title : </p>
            <input type="text" name="title" maxlength="50" placeholder="50자 이내로 작성해주세요." style="width: 90%; height: 100%; float: right; background-color: #f2f2f2; border: 0;"></input>
          </div>
        
        <textarea name="contents" rows="38" placeholder="내용(최대 1500자)" style="width: 100%; background-color: #f2f2f2; border: 0;"></textarea>
        <input type="submit" name="post" value="POST" class="postbtn"></input>
      </form>
  </section>    
</main>



  </body>
</html>