<?php 
//어드민의 이메일과, 비밀번호를 적어주세요
$admin_email = "frank050721@gmail.com";
$admin_password = "hs5764438!";

?>


<?php 
$email = (string)$_POST['email'];
$password = (string)$_POST['password'];

//아무것도 입력하지 않았다면
if ($email == "" or $password == "") {
	echo "<script language=javascript> alert('이메일이나 비밀번호를 입력해주세요'); history.back(-1); </script>";
}else{

	//어드민 검증로직
	if ($email == $admin_email && $password == $admin_password) {
		//어드민 로그인 성공
		//세션에 email저장
		session_start();
		$_SESSION['email'] = $email;

		if ((int)$_POST['radio'] == 1) {
			setcookie("memberDataEmail", $email, time() + 60*60*24*7);
			setcookie("memberDataPw", $password, time() + 60*60*24*7);
		}
		//어드민 세션 만들기(index.php에서 어드민 창 들어갈때 사용)
		$_SESSION['admin'] = 1;
		echo "<script language=javascript> alert('어드민님 환영합니다'); window.location = './index.php'; </script>";	
	}



	//mysql 접속
	$mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
	//email이 $email인 사람 정보 가져오기
	$check = "SELECT * FROM members WHERE email='$email' ";
	$result = $mysqli->query($check);
	$row = mysqli_fetch_array($result);

	//비밀번호 검증로직
	$hashedPassword = $row['pw']; 
	$passwordResult = password_verify($password, $hashedPassword);
	if ($passwordResult == true){
		//로그인성공
		//세션에 email저장
		session_start();
		$_SESSION['email'] = $row['email'];
		if ((int)$_POST['radio'] == 1) {
			setcookie("memberDataEmail", $email, time() + 60*60*24*7);
			setcookie("memberDataPw", $password, time() + 60*60*24*7);
		}
		echo "<script language=javascript> alert('로그인 되었습니다'); window.location = './index.php'; </script>";	
	}else{
		//로그인실패
		echo "<script language=javascript> alert('아이디나 비밀번호가 일치하지 않습니다'); window.location = './index.php'; </script>";	
	}
}


?>