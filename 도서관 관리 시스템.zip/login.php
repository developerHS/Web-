<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
        <style type="text/css">
      body {
        background: url("./images/main_theme1.png");
        position: center;
        background-size: cover;
        height: 100vh; //Change this as per design needs
        width: 100%; //Change this as per design needs
        opacity: 0.5;

      }

    </style>
  </head>
  <body>

<div class="container">
  <form class="px-4 py-3" action="./login_check.php" method="post">
    <div class="mb-3">
      <label for="exampleDropdownFormEmail1" class="form-label">이메일</label>
      <input type="email" class="form-control" id="exampleDropdownFormEmail1" placeholder="email@example.com" name="email">
    </div>
    <div class="mb-3">
      <label for="exampleDropdownFormPassword1" class="form-label">비밀번호</label>
      <input type="password" class="form-control" id="exampleDropdownFormPassword1" placeholder="Password" name="password">
    </div>
    <div class="mb-3">
      <div class="form-check">
        <input type="checkbox" class="form-check-input" id="dropdownCheck" name="radio" value="1">
        <label class="form-check-label" for="dropdownCheck">
          아이디 기억하기
        </label>
      </div>
    </div>
    <button type="submit" class="btn btn-primary">Sign in</button>
  </form>
  <div class="dropdown-divider"></div>
  <a class="dropdown-item" href="./signup.php">회원가입</a>
</div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>

