mysql 콘솔창에 입력하세요

첫번째 입력할거(db생성)----------------------------
CREATE DATABASE library

두번째 입력할거(책 테이블)
create table books(
	_id INT PRIMARY KEY AUTO_INCREMENT,
	title VARCHAR(100) NOT NULL,
	author VARCHAR(100) NOT NULL,
	img_location VARCHAR(200) NOT NULL DEFAULT "./images/small_img_no.gif",
	views INT DEFAULT 0,
	borrowed_bool INT NOT NULL DEFAULT 0,
	brrowed_member INT NOT NULL,
	booked_bool INT NOT NULL DEFAULT 0,
	booked_member INT NOT NULL
) ENGINE=INNODB; 
DESCRIBE books

세번째 입력할거(유저테이블)
create table members(
	_id INT PRIMARY KEY AUTO_INCREMENT,
	name VARCHAR(100) NOT NULL,
	email VARCHAR(100) NOT NULL,
	pw VARCHAR(100) NOT NULL,
	sex INT NOT NULL,
	ban_bool INT DEFAULT 0
) ENGINE=INNODB; 
DESCRIBE members

네번째 입력할거(책 요청 게시판)
create table bookNoticeBoard(
	_id INT PRIMARY KEY AUTO_INCREMENT,
	title VARCHAR(100) NOT NULL,
	name VARCHAR(100) NOT NULL,
	nowtime VARCHAR(100) NOT NULL,
	contents VARCHAR(100) NOT NULL
)  CHARSET=utf8 COLLATE=utf8_general_ci ENGINE=INNODB; 
DESCRIBE bookNoticeBoard