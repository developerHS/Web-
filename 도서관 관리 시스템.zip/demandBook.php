<?php
//쿠키정보로 로그인 
$loginAble = false;
$name = "UNKNOWN";
if (isset($_COOKIE['memberDataEmail']) && isset($_COOKIE['memberDataPw'])) {
  $email = $_COOKIE['memberDataEmail'];
  $password = $_COOKIE['memberDataPw'];
  //mysql 접속
  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  //email이 $email인 사람 정보 가져오기
  $check = "SELECT * FROM members WHERE email='$email' ";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  if (mysqli_num_rows($result) > 0) {
      //비밀번호 검증로직
      $hashedPassword = $row['pw']; 
      $passwordResult = password_verify($password, $hashedPassword);
      if ($passwordResult) {
        //로그인 허용
        $_SESSION['email'] = $row['email'];
        $name = $row['name'];
        $loginAble = true; //쿠키정보로 로그인
        mysqli_close($mysqli);
      }
  }else{
    mysqli_close($mysqli);
  }
}
//세션정보로 로그인
session_start();
if ($loginAble == false) {
  if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    //mysql 접속
    $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
    //email이 $email인 사람 정보 가져오기
    $check = "SELECT * FROM members WHERE email='$email' ";
    $result = $mysqli->query($check);
    $row = mysqli_fetch_array($result);
      if (mysqli_num_rows($result) > 0) {
        //이메일 검증로직
        $mysqlEmail = $row['email']; 
          if ($mysqlEmail == $email) {
            //로그인 허용
            $name = $row['name'];
            $loginAble = true; //세션정보로 로그인
          }
      }
        mysqli_close($mysqli);
  }

}
?>

<?php 
//벤 여부 판단
if ($loginAble == true) {
  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  $check = "SELECT * FROM members WHERE email='$email'";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  if (mysqli_num_rows($result) > 0) {
    //객체가 존재한다면(객체는 무조건 존재해야함. 만약 없다면 오류)
    $ban_bool = $row['ban_bool'];
    if ($ban_bool == 1) {
      //밴이라면


    }else{
      //밴이 아니라면


    }
  }
}

?>

<?php
//버튼 이벤트
function logout() {
  session_destroy();
  unset($_COOKIE['memberDataEmail']);
  unset($_COOKIE['memberDataPw']);
  setcookie('memberDataEmail', '', time() - 3600, '/');
  setcookie('memberDataPw', '', time() - 3600, '/');
  header("location: ./index.php");

} 
function login() {
  header("location: ./login.php");

} 
if(array_key_exists('logout',$_POST)){ 
  logout(); 
}
if(array_key_exists('login',$_POST)){ 
  login(); 
}
?>

<?php 
//페이징
//페이징
if (isset($_GET['page'])) {
  $page = $_GET['page'];
}else{
  $page = 1;
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>책 요청 게시판</title>

    <style type="text/css">
      body {
        background: url("./images/main_theme1.png");
        position: center;
        background-size: cover;
        height: 100vh; //Change this as per design needs
        width: 100%; //Change this as per design needs
        opacity: 0.5;

      }

    </style>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  </head>
  <body>
    <!--JavaScript-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

<!--navigation-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Library</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php">도서관소개</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./search.php">도서검색</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./demandBook.php">책 요청 게시판</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./iBookedBook.php">예약한책</a>
        </li>
        <?php 
        if (isset($_SESSION['admin'])) {
          if ($_SESSION['admin'] == 1) {
            //어드민 인증완료 네비게이션에 어드민창으로 가는 li추가
            echo "
        <li class='nav-item'>
          <a class='nav-link' href='./book_register.php'>도서 등록(관리자전용)</a>
        </li>
            ";
          }
        }
        ?>
      </ul>
    <?php 
    if ($loginAble == true) {
      echo "      
      <form class='d-flex' method='post' action='./index.php'>
        <span class='navbar-text'>
          $name 님 환영합니다&nbsp;&nbsp;&nbsp;
        </span>
        <input class='btn btn-outline-dark' type='submit' name='logout' value='Logout'></input>
      </form>";
    }else{

        echo "
      <form class='d-flex' method='post' action='./index.php'>
        <input class='btn btn-outline-dark' type='submit' name='login' value='Login'></input>
      </form>";

     
    }
 ?>
    </div>
  </div>
</nav>  


<!--컨테이너-->
<br>

<main role="main" class="container bg-light">
  <h2 class="text-center">책 요청 게시판</h2>


<table class="table table-striped table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">제목</th>
      <th scope="col">이름</th>
      <th scope="col">시간</th>
    </tr>
  </thead>
  <tbody>

<?php 
$mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  // 한글 깨짐 관련
    mysqli_query($mysqli, "set session character_set_database=utf8;");
    mysqli_query($mysqli, "set session character_set_results=utf8;");
    mysqli_query($mysqli, "set session character_set_client=utf8;");
$check = "SELECT count(*) as cnt FROM bookNoticeBoard";
$result = $mysqli->query($check);
$row = mysqli_fetch_array($result);
$cnt = (int)$row['cnt'];



     

                    
                    // 페이징 구현                                                                   
                    $sql = $mysqli->query("SELECT * FROM bookNoticeBoard");
                    
                    $total_record = mysqli_num_rows($sql); // 불러올 게시물 총 개수

                    $list = 10; // 한 페이지에 보여줄 게시물 개수
                    $block_cnt = 5; // 하단에 표시할 블록 당 페이지 개수
                    $block_num = ceil($page / $block_cnt); // 현재 페이지 블록
                    $block_start = (($block_num - 1) * $block_cnt) + 1; // 블록의 시작 번호
                    $block_end = $block_start + $block_cnt - 1; // 블록의 마지막 번호

                    $total_page = ceil($total_record / $list); // 페이징한 페이지 수
                    if($block_end > $total_page){
                        $block_end = $total_page; // 블록 마지막 번호가 총 페이지 수보다 크면 마지막 페이지 번호를 총 페이지 수로 지정함
                    }
                    $total_block = ceil($total_page / $block_cnt); // 블록의 총 개수
                    $page_start = ($page - 1) * $list; // 페이지의 시작 (SQL문에서 LIMIT 조건 걸 때 사용)

                    // 게시물 목록 가져오기                
                    $sql2 = $mysqli->query("SELECT * FROM bookNoticeBoard order by _id desc LIMIT $page_start, $list"); // $page_start를 시작으로 $list의 수만큼 보여주도록 가져옴                                   
                    
                    while($board = $sql2->fetch_array()){
                        $title=$board["title"];
                        /* 제목 글자수가 30이 넘으면 ... 표시로 처리해주기 */
                        if(strlen($title)>30){
                            $title=str_replace($board["title"],mb_substr($board["title"],0,30,"utf-8")."...",$board["title"]);
                        }   
                        $id = $board['_id'];
                        $title = $board['title'];
                        $name = $board['name'];
                        $time = $board['nowtime'];                            
                    ?>

                                                    
                      <tr>
                        <th scope='row'><?php echo "$id";?></th>
                        <td><?php echo "$title"; ?></td>
                        <td><?php echo "$name"; ?></td>
                        <td><?php echo "$time"; ?></td>
                      </tr>

                    <?php                
                    }                                                                                                            
                    ?>

  </tbody>
</table>
<!-- 게시물 목록 중앙 하단 페이징 부분-->
                <nav aria-label="Page navigation example">
                    <ul class="pagination justify-content-center">
                        <?php
                            if ($page <= 1){
                                // 빈 값
                            } else {
                                if(isset($unum)){
                                    echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=1' aria-label='Previous'>처음</a></li>";
                                } else {
                                    echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=1' aria-label='Previous'>처음</a></li>";
                                }
                            }
                            
                            if ($page <= 1){
                                // 빈 값
                            } else {
                                $pre = $page - 1;
                                if(isset($unum)){
                                    echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=$pre'>◀ 이전 </a></li>";
                                } else {
                                    echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=$pre'>◀ 이전 </a></li>";
                                }
                            }
                            
                            for($i = $block_start; $i <= $block_end; $i++){
                                if($page == $i){
                                    echo "<li class='page-item'><a class='page-link' disabled><b style='color: #df7366;'> $i </b></a></li>";
                                } else {
                                    if(isset($unum)){
                                        echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=$i'> $i </a></li>";
                                    } else {
                                        echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=$i'> $i </a></li>";
                                    }
                                }
                            }
                            
                            if($page >= $total_page){
                                // 빈 값
                            } else {
                                $next = $page + 1;
                                if(isset($unum)){
                                    echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=$next'> 다음 ▶</a></li>";
                                } else {
                                    echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=$next'> 다음 ▶</a></li>";
                                }
                            }
                            
                            if($page >= $total_page){
                                // 빈 값
                            } else {
                                if(isset($unum)){
                                    echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=$total_page'>마지막</a>";
                                } else {
                                    echo "<li class='page-item'><a class='page-link' href='./demandBook.php?page=$total_page'>마지막</a>";
                                }
                            }
                        ?>                                        
                    </ul>  
<form class='d-flex' method='post' action='./post.php'>
        <input class='btn btn-outline-dark' type='submit' name='글쓰기' value='글쓰기'></input>
</form>                                                             
                </nav>               
</main>



  </body>
</html>