
<?php
//쿠키정보로 로그인 
$loginAble = false;
$name = "UNKNOWN";
if (isset($_COOKIE['memberDataEmail']) && isset($_COOKIE['memberDataPw'])) {
  $email = $_COOKIE['memberDataEmail'];
  $password = $_COOKIE['memberDataPw'];
  //mysql 접속
  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  //email이 $email인 사람 정보 가져오기
  $check = "SELECT * FROM members WHERE email='$email' ";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  if (mysqli_num_rows($result) > 0) {
      //비밀번호 검증로직
      $hashedPassword = $row['pw']; 
      $passwordResult = password_verify($password, $hashedPassword);
      if ($passwordResult) {
        //로그인 허용
        $_SESSION['email'] = $row['email'];
        $name = $row['name'];
        $loginAble = true; //쿠키정보로 로그인
        mysqli_close($mysqli);
      }
  }else{
    mysqli_close($mysqli);
  }
}
//세션정보로 로그인
session_start();
if ($loginAble == false) {
  if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    //mysql 접속
    $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
    //email이 $email인 사람 정보 가져오기
    $check = "SELECT * FROM members WHERE email='$email' ";
    $result = $mysqli->query($check);
    $row = mysqli_fetch_array($result);
      if (mysqli_num_rows($result) > 0) {
        //이메일 검증로직
        $mysqlEmail = $row['email']; 
          if ($mysqlEmail == $email) {
            //로그인 허용
            $name = $row['name'];
            $loginAble = true; //세션정보로 로그인
          }
      }
        mysqli_close($mysqli);
  }

}
?>

<?php 
//벤 여부 판단
if ($loginAble == true) {
  $mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
  $check = "SELECT * FROM members WHERE email='$email'";
  $result = $mysqli->query($check);
  $row = mysqli_fetch_array($result);
  if (mysqli_num_rows($result) > 0) {
    //객체가 존재한다면(객체는 무조건 존재해야함. 만약 없다면 오류)
    $ban_bool = $row['ban_bool'];
    if ($ban_bool == 1) {
      //밴이라면


    }else{
      //밴이 아니라면


    }
  }
}

?>

<?php
//버튼 이벤트
function logout() {
  session_destroy();
  unset($_COOKIE['memberDataEmail']);
  unset($_COOKIE['memberDataPw']);
  setcookie('memberDataEmail', '', time() - 3600, '/');
  setcookie('memberDataPw', '', time() - 3600, '/');
  header("location: ./index.php");

} 
function login() {
  header("location: ./login.php");

} 
function borrow() {
  $id=$_SESSION['email'];

  $mysqli=mysqli_connect("localhost","root","hs5764438!","library");  
  $check="SELECT *FROM members WHERE email='$id'";
  $result=$mysqli->query($check);
  if($result->num_rows==1){
    $row=$result->fetch_array(MYSQLI_ASSOC);
  } 
  $memberId = (int)$row['_id'];
  $pstm = $_GET['postnumber'];
  $check="SELECT *FROM books WHERE _id=$pstm";
  $result=$mysqli->query($check);
  if($result->num_rows==1){
    $row=$result->fetch_array(MYSQLI_ASSOC);
  } 
  if ($row['borrowed_bool'] == 1 or $row['booked_bool'] == 1) {
    echo "<script language=javascript> if (confirm('대출 되거나 예약된 책입니다!') == true){  location.href = ' ./search.php';}else{location.href = ' ./search.php';}</script>"; 
    exit();
  }

   
  $check="UPDATE books SET borrowed_bool=1 WHERE _id=$pstm";
  $result=$mysqli->query($check);
  $check="UPDATE books SET brrowed_member=$memberId WHERE _id=$pstm";
  $result=$mysqli->query($check);
  mysqli_close($mysqli);
    echo "<script language=javascript> if (confirm('대출 되었습니다!') == true){  location.href = ' ./search.php';}else{location.href = ' ./search.php';}</script>"; 

} 
function book() {
  $id=$_SESSION['email'];

  $mysqli=mysqli_connect("localhost","root","hs5764438!","library");  
  $check="SELECT *FROM members WHERE email='$id'";
  $result=$mysqli->query($check);
  if($result->num_rows==1){
    $row=$result->fetch_array(MYSQLI_ASSOC);
  } 
  $memberId = (int)$row['_id'];
  $pstm = $_GET['postnumber'];
  $check="SELECT *FROM books WHERE _id=$pstm";
  $result=$mysqli->query($check);
  if($result->num_rows==1){
    $row=$result->fetch_array(MYSQLI_ASSOC);
  } 
  if ($row['borrowed_bool'] == 1 or $row['booked_bool'] == 1) {
    echo "<script language=javascript> if (confirm('대출 되거나 예약된 책입니다!') == true){  location.href = ' ./search.php';}else{location.href = ' ./search.php';}</script>"; 
    exit();
  }

   
  $check="UPDATE books SET booked_bool=1 WHERE _id=$pstm";
  $result=$mysqli->query($check);
  $check="UPDATE books SET booked_member=$memberId WHERE _id=$pstm";
  $result=$mysqli->query($check);
  mysqli_close($mysqli);
    echo "<script language=javascript> if (confirm('예약 되었습니다!') == true){  location.href = ' ./search.php';}else{location.href = ' ./search.php';}</script>"; 
} 
if(array_key_exists('logout',$_POST)){ 
  logout(); 
}
if(array_key_exists('login',$_POST)){ 
  login(); 
}
if(array_key_exists('borrow',$_POST)){ 
  borrow();
}
if(array_key_exists('book',$_POST)){ 
  book(); 
}
?>


<?php  
function cleanStr($str){  //인자로 오는 값이 숫자가 아니면 경고
  if (preg_match('/[^0-9-]/', $str)) {
    echo "<script language=javascript> if (confirm('존재하지 않는 책입니다.') == true){  location.href = ' ./search.php';}else{location.href = ' ./search.php';}</script>"; 
    exit();
  }else{
   return $str;
   exit();
  } 
}


  $id=$_SESSION['email'];

  $mysqli=mysqli_connect("localhost","root","hs5764438!","library");
  $check="SELECT *FROM members WHERE email='$id'";
  $result=$mysqli->query($check);
  if($result->num_rows==1){
    $row=$result->fetch_array(MYSQLI_ASSOC);
  } 


if (!isset($_SESSION['email']) or $row['ban_bool'] == 1) { //세션이 없거나 벤되어 있으면 경고
  echo "<script language=javascript> if (confirm('접근 권한 없음. 로그인해주세요!') == true){  location.href = ' ./index.php';}else{location.href = ' ./index.php';}</script>"; 
  exit();
}

$postnumber = cleanStr($_GET['postnumber']); //최종 포스트넘버 확정

$mysqli=mysqli_connect("localhost","root","hs5764438!","library");
  $check="SELECT *FROM books WHERE _id=$postnumber";
  $result=$mysqli->query($check);
    if($result->num_rows==1){
      $row=$result->fetch_array(MYSQLI_ASSOC);
    }   
  if($row['title']==NULL || $row['author']==NULL){  
        echo "<script language=javascript> if (confirm('존재하지 않는 게시물입니다.') == true){  location.href = ' ./search.php';}else{location.href = ' ./search.php';}</script>"; 
    exit(); 
  }

  $views = $row['views'] + 1;
  $check="UPDATE books SET views=$views WHERE _id=$postnumber"; //조회수 업데이트 쿼리
  $result=$mysqli->query($check);

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title></title>

    <style type="text/css">
      body {
        background: url("./images/main_theme1.png");
        position: center;
        background-size: cover;
        height: 100vh; //Change this as per design needs
        width: 100%; //Change this as per design needs
        opacity: 0.5;

      }

    </style>
  </head>
  <body>
    <!--JavaScript-->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

<!--navigation-->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Library</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="./index.php">도서관소개</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./search.php">도서검색</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./demandBook.php">책 요청 게시판</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="./iBookedBook.php">예약한책</a>
        </li>
        <?php 
        if (isset($_SESSION['admin'])) {
          if ($_SESSION['admin'] == 1) {
            //어드민 인증완료 네비게이션에 어드민창으로 가는 li추가
            echo "
        <li class='nav-item'>
          <a class='nav-link' href='./book_register.php'>도서 등록(관리자전용)</a>
        </li>
            ";
          }
        }
        ?>
      </ul>
              <?php 
    if ($loginAble == true) {
      echo "      
      <form class='d-flex' method='post' action='./index.php'>
        <span class='navbar-text'>
          $name 님 환영합니다&nbsp;&nbsp;&nbsp;
        </span>
        <input class='btn btn-outline-dark' type='submit' name='logout' value='Logout'></input>
      </form>";
    }else{

        echo "
      <form class='d-flex' method='post' action='./index.php'>
        <input class='btn btn-outline-dark' type='submit' name='login' value='Login'></input>
      </form>";

     
    }
 ?>
    </div>
  </div>
</nav>  


<!--컨테이너-->
<br>
<main class="container bg-light">
<?php 
$title = $row['title'];

?>

<form method="post" action="">
<h2><?php echo "$title"; ?></h2>  
<input type="submit" class="btn btn-warning" value="대출" name="borrow"></input>
<input type="submit" class="btn btn-warning" value="예약" name="book"></input>
<?php 
if ($row['borrowed_bool'] == 1) {
  //대출 되었을때
  echo "<p>이미 대출됨</p>";
}
if ($row['booked_bool'] == 1) {
  //대출 되었을때
  echo "<p>이미 예약됨</p>";
}
?>
</form>


</main>

  </body>
</html>