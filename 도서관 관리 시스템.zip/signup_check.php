<?php 
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$sex = (int)$_POST['gridRadios'];

//공백칸이 있는지 
if ($name == "" || $email == "" || $password == "") {
	echo "<script language=javascript> alert('채우지 않은 칸이 있습니다!!'); history.back(-1); </script>";		
}else{
	//비밀번호 암호화
	$encrypted_pw = password_hash($password, PASSWORD_DEFAULT);

	//mysql 접속
	$mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
	$check = "INSERT INTO members(name, email, pw, sex) VALUES ('$name', '$email', '$encrypted_pw', '$sex') ";
	$result = $mysqli->query($check);


	echo "<script language=javascript> alert('회원가입 성공!!'); history.back(-1); </script>";


}


?>