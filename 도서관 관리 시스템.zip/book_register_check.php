<?php 
if ($_POST['title'] == "" || $_POST['author'] == "") {
	//빈칸을 채우지 않았다면
	echo "<script language=javascript> alert('채우지 않은 칸이 있습니다!!'); window.location = './book_register.php'; </script>";	
	exit;		
}
?>



<?php 
//파일 업로드 로직
$uploads_dir = './images/book_img'; //업로드될 폴더
$allowed_ext = array('jpg', 'jpeg', 'png', 'gif');

$error = $_FILES['myfile']['error'];
$name = $_FILES['myfile']['name'];
$ext = array_pop(explode('.', $name));

//오류확인
if ($error != UPLOAD_ERR_OK) {
	switch ($error) {
		case UPLOAD_ERR_INI_SIZE:
		case UPLOAD_ERR_FORM_SIZE:
			echo "<script language=javascript> alert('파일이 너무 큽니다.'); window.location = './book_register.php'; </script>";
			exit;
			break;
		
		case UPLOAD_ERR_NO_FILE:
			echo "<script language=javascript> alert('파일이 첨부되지 않았습니다. ($error)'); window.location = './book_register.php'; </script>";
			exit;
			break;
		default:
			echo "<script language=javascript> alert('파일이 제대로 업로드 되지 않았습니다. ($error)'); window.location = './book_register.php'; </script>";
			exit;
			break;
	}
	exit;
}

//활장자 확인
if (!in_array($ext, $allowed_ext)) {
	echo "<script language=javascript> alert('허용되지 않는 확장자 입니다.'); window.location = './book_register.php'; </script>";	
	exit;
}

//파일이동
move_uploaded_file($_FILES['myfile']['tmp_name'], "$uploads_dir/$name");

//파일 바이트 초과 확인
$max_size = 20000000; //20메가 바이트
if ($_FILES['myfile']['size'] > $max_size) {
	echo "<script language=javascript> alert('파일이 너무 큽니다. 20M 최대'); window.location = './book_register.php'; </script>";	
	exit;	
}
?>

<?php 
//mysql에 등록

$bookTitle = $_POST['title']; 
$bookAuthor = $_POST['author'];
$imgLocation = "$uploads_dir/$name"; 
$mysqli = mysqli_connect("localhost", "root", "hs5764438!", "library");
$check = "INSERT INTO books(title, author, img_location) VALUES ('$bookTitle', '$bookAuthor', '$imgLocation') ";
$result = $mysqli->query($check);

echo "<script language=javascript> alert('등록 완료'); window.location = './book_register.php'; </script>";	
exit();


?>
